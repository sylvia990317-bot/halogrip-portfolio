HALOGRIP scenario image assets

Canvas/background color: #F3F2EE

Files:
- 01-authorize.png
- 02-activate.png
- 03-reposition.png
- 04-park.png
- 05-complete.png
- background-F3F2EE.png

The five storyboard images have been extracted from the supplied original storyboard.
Their white backgrounds were composited into the exact #F3F2EE color while preserving
the black linework and restrained red annotations.

For the website, use CSS background-color: #F3F2EE rather than loading the plain
background PNG. The PNG is included only as an exact color reference.
